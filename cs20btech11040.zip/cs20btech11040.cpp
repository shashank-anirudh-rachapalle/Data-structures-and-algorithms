#include <iostream>
#include <vector>
#define NUM_PEOPLE 100

typedef struct graph_node
{
    int id;
    int height;
    struct list_node* head;
}graph_node;

graph_node* create_graph_node(int id)
{
    graph_node* new_node=(graph_node*)malloc(sizeof(graph_node));
    new_node->head=NULL;
    new_node->height=-1;
    new_node->id=id;
    return new_node;
}

typedef struct list_node
{
    graph_node* neighbour;
    struct list_node* next;
}list_node;

graph_node* adj_list[NUM_PEOPLE];

void add_to_list(list_node** head,list_node* add_node)
{
    if(*head==NULL)
    {
        *head=add_node;
        return;
    }
    list_node* temp=*head;
    while(true)
    {
        if(temp->next==NULL)
        {
            temp->next=add_node;
            break;
        }
        temp=temp->next;
    }
}

list_node* create_list_node(graph_node* neighbour)
{
    list_node* return_node=(list_node*)malloc(sizeof(list_node));
    return_node->neighbour=neighbour;
    return_node->next=NULL;
    return return_node;
}

void create_graph()
{
    for(int i=0;i<NUM_PEOPLE;i++)
    {
        for(int j=i+1;j<NUM_PEOPLE;j++)
        {
            if(std::rand()%2)
            {
                add_to_list(&adj_list[i]->head,create_list_node(adj_list[j]));
                add_to_list(&adj_list[j]->head,create_list_node(adj_list[i]));
            }
        }
    }
}

void print_graph()
{
    for(int i=0;i<NUM_PEOPLE;i++)
    {
        std::cout<<adj_list[i]->id<<"->";
        list_node* start=adj_list[i]->head;
        while(start!=NULL)
        {
            std::cout<<start->neighbour->id<<" ";
            start=start->next;
        }
        std::cout<<std::endl;
    }
}

void assign_height(int source_id)
{
    list_node* head = adj_list[source_id]->head;
            std::vector<int> personids;


    while(head)
    {
        if(head->neighbour->height == -1 || head->neighbour->height > adj_list[source_id]->height + 1)
        {
            //reassign the height
            head->neighbour->height = adj_list[source_id]->height + 1;
            personids.push_back(head->neighbour->id);
        }
        head = head->next;
    }

    for(int neighbors: personids)
    {
        assign_height(neighbors);
    }
}



enum event{infection, recovery};

typedef struct
{
    int person_id;
    int timeStamp;
    int type;

}time_stamp;

std::vector<time_stamp*> heap_storage;


int parent(int i)
{
    return (i-1)/2;
}

int left_child(int i)
{
    return 2*i+1;
}

int right_child(int i)
{
    return 2*i+2;
}

void add_element_heap( int person_id, int time, int type)
{
    time_stamp* new_entry = (time_stamp*)malloc(sizeof(time_stamp));
    new_entry->person_id = person_id;
    new_entry->timeStamp = time;
    new_entry->type = type;

    //now let us start swaping 
   

    int size = heap_storage.size();


    heap_storage.push_back(new_entry);

    if(!size) return;



    while(heap_storage[parent(size)]->timeStamp > heap_storage[size]->timeStamp)
    {
        std::swap(heap_storage[parent(size)],heap_storage[size]);
    }
}

void heapify(int index)
{
    //base cases
    if(left_child(index) > heap_storage.size()-1) return;

    if(left_child(index) == heap_storage.size()-1)
    {
        //here only left child is present
        if(heap_storage[left_child(index)]->timeStamp < heap_storage[index]->timeStamp)
        std::swap(heap_storage[index], heap_storage[left_child(index)]);
        return;
    }

    if(heap_storage[index]->timeStamp < heap_storage[left_child(index)]->timeStamp
        && heap_storage[index]->timeStamp < heap_storage[right_child(index)]->timeStamp)
        return;

    if(heap_storage[left_child(index)]->timeStamp < heap_storage[right_child(index)]->timeStamp)
    {
        std::swap(heap_storage[left_child(index)],heap_storage[index]);
        heapify(left_child(index));
    }
    else 
    {
        std::swap(heap_storage[right_child(index)],heap_storage[index]);
        heapify(right_child(index));

    }



}

time_stamp* delete_min()
{
    time_stamp* min = heap_storage.front();
    if(heap_storage.size() == 1)
    {
        heap_storage.pop_back();
        return min;
    }

    std::swap(heap_storage.front(), heap_storage.back());
    heap_storage.pop_back();

    heapify(0);
    
    return min;
}

typedef struct
{
    //if for an index is_in_set is 1 implies that the person is in the particular array
    bool is_in_set;
    int time_stamp;

}status;

status susceptible[NUM_PEOPLE], infected[NUM_PEOPLE], recovered[NUM_PEOPLE];

void set_all_arrays()
{
    status temp;
    for(int i=0; i<NUM_PEOPLE; i++)
    {
        temp.is_in_set = 1;
        temp.time_stamp = -1;
        susceptible[i] = temp;

        temp.is_in_set = 0;
        infected[i] = temp;
        recovered[i] = temp;
    }
}

void print_report(int day_number)
{
    int susc_count=0, recover_count=0, infect_count=0;
    for(int i=0; i<NUM_PEOPLE; i++)
    {
        if(susceptible[i].is_in_set) susc_count++;
        if(infected[i].is_in_set) infect_count++;
        if(recovered[i].is_in_set) recover_count++;
    }

    std::cout<< "Day "<<day_number<<": ";
    std::cout<< "Susceptible: "<<susc_count<<" Infected: "<<infect_count<<" Recovered: "<<recover_count<<std::endl;
}

void infection_flow()
{
    int day_number = 0;
    std::srand(time(NULL));
    int source_person = std::rand() % NUM_PEOPLE;
    adj_list[source_person]->height = 0;
    assign_height(source_person);
    std::cout<<"source person id is "<<source_person<<std::endl;

    add_element_heap(source_person,0, infection);
    add_element_heap(source_person,1+std::rand() % 5, recovery);
    //std::cout<<heap_storage.size()<<std::endl;   
    int day = 0;


    while(heap_storage.size())
    {
        

        time_stamp *temp = delete_min();
        //std::cout<<" Deleted "<<temp->person_id<<" from the heap_storage\n";

        if(day_number == temp->timeStamp)
        {
           print_report(day_number);
            day_number++;

        }

        if(temp->type == recovery)
        {
            // If a particular person is recovered
            //move this person from infected to recovered
            infected[temp->person_id].is_in_set = false;
            recovered[temp->person_id].is_in_set = true;
            recovered[temp->person_id].time_stamp = temp->timeStamp;

            
        }
        else if(susceptible[temp->person_id].is_in_set)
        {
            //move this person from susceptible to infected
            susceptible[temp->person_id].is_in_set = false;
            infected[temp->person_id].is_in_set = true;
            infected[temp->person_id].time_stamp = temp->timeStamp;

            //Now we will stimulate the infected date and recovery date for the neighbors of this person

            list_node* head = adj_list[temp->person_id]->head;

            while(head)
            {
               if(susceptible[head->neighbour->id].is_in_set)
               {
                   //if the neighbor is infected then we toss a coin and infect him
                   for(int i=1; i<6; i++)
                   {
                       if(std::rand() % 2)
                       {
                           add_element_heap(head->neighbour->id, temp->timeStamp+ i, infection);
                           add_element_heap(head->neighbour->id, temp->timeStamp+ i + 1 + std::rand() % 5, recovery);
                           break;
                       }
                   }
               }
               head = head->next;
            }
        }
    }
}


void print_distance_vs_timestamp()
{
    for(int i=0; i<NUM_PEOPLE;i++)
    {
        std::cout<<i<<" : "<<"height "<<adj_list[i]->height<<" time stamp "<<infected[i].time_stamp<<std::endl;
    }
}


int main()
{
    for(int i=0;i<NUM_PEOPLE;i++)
    {
        adj_list[i]=create_graph_node(i);
    }
    create_graph();
    //print_graph();
    set_all_arrays();
    infection_flow();
    print_distance_vs_timestamp();
    return 0;
}