import matplotlib.pyplot as plt

x = [0,1,2,3,4,5,6,7,8]
plt.xlabel('Days')

y = [100,99,92,28,0,0,0,0,0]
plt.ylabel('Number of susceptible')
plt.plot(x,y)
plt.show()

y = [0,1,7,66,56,8,3,0,0]
plt.ylabel('Number of infected')
plt.plot(x,y)
plt.show()

y = [0,0,1,6,45,92,97,100,100]
plt.ylabel('Number of recovered')
plt.plot(x,y)
plt.show()

